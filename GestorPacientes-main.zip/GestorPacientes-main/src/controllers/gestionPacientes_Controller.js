
// crear una nueva cita de paciente

const crearPacienteController = (req,res) =>{

}

// visualizar las citas de los pacientes por ID

const verPacienteController = (req,res) =>{
    const pacienteId = req.params.id
}

// visualizar todos los pacientes que se encuentran registrados 

const verTodosPacientesController = (req,res) =>{

}

// Actualizar la ficha de los pacientes que ya se encontraban registrados


const actualizarPacienteController = (req,res) =>{

}

// borrar ficha del paciente por ID

const borrarPacienteController = (req,res) =>{

}

export {
    crearPacienteController,
    verPacienteController,
    verTodosPacientesController,
    actualizarPacienteController,
    borrarPacienteController
}


