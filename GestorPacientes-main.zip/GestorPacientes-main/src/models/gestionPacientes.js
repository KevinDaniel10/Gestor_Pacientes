const pacientes ={

    // para poder crear un nuevo paciente 
    crearPacienteModelo(){
         
    }
    ,

    // para poder ver un paciente en especifico 

    verPacienteModelo(){

    }
    ,

    // para poder ver todos los pacientes 

    verTodosPacientesModelo(){

    }
    ,

    // para actualizar paciente 

    actualizarPacienteModelo(){

    }
    ,

    // para borrar paciente 

    borrarPacienteModelo(){

    }
}

export default pacientes